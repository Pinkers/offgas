# Just the version of the package

__version__ = '0.2.5'
